 
//Ball One
var xcoord = Math.floor(Math.random() * 850) + 50; // Random Placement for Ball in X-Coordinate
var ycoord = 50;
var xcoordS = 10;
var ycoordS = (7,12);

//Ball Two
var xcoord2 = Math.floor(Math.random() * 850) + 50; // Random Placement for Ball in X-Coordinate
var ycoord2 = 50;
var xcoordS2 = 10;
var ycoordS2 = (5,8);

//Distraction Ball
var xcoord1 = 450; 
var ycoord1 = 50;
var xcoordS1 = 10;
var ycoordS1 = 10;

//Avoid Ball
var xcoord3 = Math.floor(Math.random() * 850) + 50; // Random Placement for Ball in X-Coordinate
var ycoord3 = 50;
var xcoordS3 = 0;
var ycoordS3 = 7; 

// Variables Used to Keep Control of Game
var score = 0;
var highscore = 0;
let gamelives;


// Slide Function(From Class Resources): https://editor.p5js.org/howshekilledit/sketches/k0huNiU1D
let currentSlide = 0; //initiate at slide 0
let slides; //declare variable for array of slides

var backImage; // background image
var customfont; //custom font - Where I learned to import custom fonts: https://github.com/processing/p5.js/wiki/How-to-load-custom-fonts-to-p5.js-web-editor



function preload() {
  backImage = loadImage("backImage.png")
  customfont = loadFont('ARCADECLASSIC.TTF')
}

function setup() {
  createCanvas(900, 900);
  gameLives = 5; //sets the lives to 5
  loop();
  //populate array of slides with functions  -- function content starts on line 25
  slides = [slide1, slide2, slide3]; 
}

function draw() {
slides[currentSlide]();
}

//advance slide on mouse click
function mouseClicked(){
  clear();
  if(currentSlide < slides.length-1){
    currentSlide++; 
  } else{
    currentSlide = 0; //set back to zero if # slides exceded
  }
}

//put all your code for slide1 in this function - Title Screen Slide
function slide1(){
TitleScreen();
ball2();
}


//put all your code for slide2 in this function - Information Slide
function slide2(){
GameGuide();
ball2();
}

//put all your code for slide3 in this function - Game Slide
function slide3(){
image(backImage, 0, 0, width, height);
score_();
ball();
paddle();
score_();
lives_();
}


// Title of the Game.
function TitleScreen(){
  image(backImage, 0, 0, width, height);
  textSize(60);
  textFont(customfont);
  text("Nelsons Game", 250, 200);
  text("Click To Continue", 180, 450);
  
  textSize(18);
  textFont('Georgia');
  fill("white");
  text("Note: After the Game Ends, It Takes 5 Seconds to Reload.", 10, 880);
  text("By: Nelson Corral", 745, 880);
}

// Slide on how the game is played along with some general statements of glitches in the game.
function GameGuide() {
image(backImage, 0, 0, width, height);
fill("white");
textSize(40);
textFont('Georgia');
text('Information', 325, 50);
textSize(18);
text('1. The Purpose of the Game is Simple: Hit the Ball(s) off the Paddle and Achieve', 25, 100);
text('a Highscore!', 25, 130);
text('2. After the Score Increases by 10, There Will Be a New Challenge.', 25,180);
text('Challenges like a New Ball, Avoiding Objects, and Diversions/Confusion will', 25, 210);
text('Be Showcased! The Final Look Will be at Score 80.', 25, 240);
text('3. The Standard is 5 Lives. When the Ball Goes Under the Paddle or The White', 25, 290);
text('Ball Touches The Paddle, A Life is Lost. After Increments of Score 25 (25,50,75,100),', 25, 320);
text('A Life is Added as an Incentive!',25,350);
text('4. Remember to Always Avoid the White Ball.', 25, 390);
text('5. CONTROLS: Use Your Mouse to Control the Paddle. It moves horizontally.', 25, 420);

textSize(40);
text('Glitches', 350, 475);
textSize(18);
text('1. The Ball May Enter Out of Frame. When this Happens, the Game is Unplayable,', 25, 520);
text('Just Restart.', 25, 550);
text('2. The Ball will Occasionally get Stuck on the Paddle. When this Happens, Just Move', 25, 600);
text('The Paddle Away From the Ball!', 25, 630);
text('3. Theres a Glitch Where After The Game is Restarted, the Lives are Immediately Lost', 25, 680);
text('and The Game is Repeatedly Lost in Less than 1 Second. Just Restart if it Happens.', 25, 710);
text("DISCLAIMER: The Game Usually Runs Pretty Well, These are Just some of the Glitches I've", 25, 760);
text('Encountered when Running the Game Multiple Times.', 25, 790);
  
if(xcoord1 > 450) {
    fill("blue");
  }
  else {
    fill("red");
  }
textSize(50);
textFont(customfont);
text('Click To Play!', 500, 830);

textSize(18);
textFont('Georgia');
fill("white");
text("Note: After the Game Ends, It Takes 5 Seconds to Reload.", 10, 880);
text("By: Nelson Corral", 745, 880);
}


// Keeps track of the Score of how many times it hits the Ball.
// Also implemented a Highscore to keep track of your highest game. 
function score_() {
  fill("red");
  textSize(45);
  textFont(customfont);
  text("Score  " + score, 20, 50);
  text("Highscore  " + highscore, 20, 110);
  if (score > highscore) {
    highscore = score;
  }
}

// Keeps track of the lives throughout the game.
// The way a life is lost is if the ball goes underneath the paddle. 
// When lives is at 0, the game is done and resetted.
function lives_() {
  fill("blue");
  textSize(45);
  textFont(customfont);
  text("Lives  " + gameLives, 715, 50);
  
  	if (gameLives == 0) {
		textSize(60);
        fill("white");
		text("GAME OVER", 300, 400);
        restartGame();
    }
}
// This function is called in when the game is over.
// It resets the score back to 0 and lives to 5 again and it starts 5 seconds after the previous game is over. 
function restartGame() {
  redraw();
  noLoop();
  score = 0;
  
  setTimeout(() => {
   setup();
   draw();
	}, 5000);
}

function ball() {
  
  // Ball Movement
  xcoord = xcoord + xcoordS;
  ycoord = ycoord + ycoordS;
  
  
  //Bounce Effect Off Screen
  if (xcoord < 5 || xcoord > 900) {
    xcoordS = xcoordS * -1;
  }
  if (ycoord < 5 || ycoord > 900) {
    ycoordS = ycoordS * -1;
  }
  
  if(ycoord < 6){
     score = score + 1;
     } 
  
  //Reset the Ball Position
  if (ycoord > 880) {
    xcoord = Math.floor(Math.random() * 850) + 50;
    ycoord = 50;
    gameLives = gameLives - 1; 
  }
  
  //Ball Creation
  if(xcoord > 450) {
    fill("blue");
  }
  else {
    fill("red");
  }
  ellipse(xcoord,ycoord,30,30);
  
  
  if ((score > 10 && score < 31) || (score > 60)) {
    avoidball(); // Ball to Avoid (Color White)
  }
  
  if ((score > 20 && score < 41) || (score > 70)) {
    ball3(); // The Other Ball To Maintain
  }
  
  if ((score > 30 && score < 41) || (score > 70)) {
    ball2(); //Distraction Ball - Doesn't Matter. 
  }
  if((score > 50 && score < 61) || (score > 80)) {
  for (i = 1; i < 4; i++) {
   ellipse(xcoord/4 * + i, ycoord+i, 30,30); // Illiusion Balls
  } 
} 
  //Incentive - If you reach these scores, a live will be added. 
  if(score == 25 || score == 50 || score == 75 || score == 100) {
    gameLives = gameLives + 1;
    score = score + 1;
  }
}

//Distraction Ball
function ball2() {
  //Ball Creation
  if(xcoord1 > 450) {
    fill("blue");
  }
  else {
    fill("red");
  }
  ellipse(xcoord1,ycoord1,30,30);
  
  // Ball Movement
  xcoord1 = xcoord1 + xcoordS1;
  ycoord1 = ycoord1 + ycoordS1;
  
  //Bounce Effect Off Screen
  if (xcoord1 < 55 || xcoord1 > 850) {
    xcoordS1 = xcoordS1 * -1;
  }
  if (ycoord1 < 55 || ycoord1 > 850) {
    ycoordS1 = ycoordS1 * -1;
  }
}

// The other ball that needs to be maintained. Functions like the orginial ball. 
function ball3() {
  
  // Ball Movement
  xcoord2 = xcoord2 + xcoordS2;
  ycoord2 = ycoord2 + ycoordS2;
  
  
  //Bounce Effect Off Screen
  if (xcoord2 < 5 || xcoord2 > 900) {
    xcoordS2 = xcoordS2 * -1;
  }
  if (ycoord2 < 5 || ycoord2 > 900) {
    ycoordS2 = ycoordS2 * -1;
  }
  
  if(ycoord2 < 6){
     score = score + 1;
     } 
  
  //Reset the Ball Position
  if (ycoord2 > 880) {
    xcoord2 = Math.floor(Math.random() * 850) + 50;
    ycoord2 = 50;
    gameLives = gameLives - 1; 
  }
  
  //Ball Creation
  if(xcoord2 > 450) {
    fill("blue");
  }
  else {
    fill("red");
  }
  ellipse(xcoord2,ycoord2,30,30);
}

//Another obstacle. This is so to makes the game harder.
//Colored as White, this ball if it hits the paddle, a life is lost.
function avoidball() {
  // Ball Movement
  xcoord3 = xcoord3 + xcoordS3;
  ycoord3 = ycoord3 + ycoordS3;
  
  //Reset the Ball Position
  if (ycoord3 > 795) {
    xcoord3 = Math.floor(Math.random() * 850) + 0;
    ycoord3 = 50;
  }
  fill("white");
  circle(xcoord3,ycoord3,15);
}



function paddle() {
//Paddle Creation
fill("white");
rect(mouseX, 800, 100, 15);
//Bouncing Effect Off Paddle
if ((xcoord > mouseX && xcoord < mouseX + 100) && (ycoord + 10 >= 800)) {
    xcoordS = xcoordS * -1;
    ycoordS = ycoordS * -1;
    //score = score + 1; //Adds 1 to the Score every time it hits paddle
}

if ((xcoord2 > mouseX && xcoord2 < mouseX + 100) && (ycoord2 + 10 >= 800)) {
    xcoordS2 = xcoordS2 * -1;
    ycoordS2 = ycoordS2 * -1;
}
//White Ball - If contacted onto the paddle, player loses a live. 
if ((xcoord3 > mouseX && xcoord3 < mouseX + 100) && (ycoord3 + 10 >= 800)) {
  gameLives = gameLives -1;
}
  
textSize(18);
  textFont('Georgia');
  fill("white");
  text("Note: After the Game Ends, It Takes 5 Seconds to Reload.", 10, 880);
  text("By: Nelson Corral", 745, 880);
}
