// Nelson Corral
// ART 151
// Project 3
// Morgan Green

let currentSlide = 0; //initiate at slide 0
let slides; //declare variable for array of slides

// Slide Function(From Class Resources): https://editor.p5js.org/howshekilledit/sketches/k0huNiU1D

// Slide 1
var title;

// Slide 2
var data;
var tempData = [];
var yearData = [];
var gwarming;

// Slide 3
var data1;
var meltData = [];
var yearData1 = [];

var sunI;
var cubeI;
var meltI;

// Slide 4
let h1, w1;
waterValues = [];

//Slide 6
var diam = 100;
var expand = true;


//Preload Function takes in images and datasets I uploaded for each slide.
function preload(){
  //Slide 1
  title = loadImage("title.jpg");
  
  //Slide 2
  data = loadTable("temp.csv", "csv", "header");
  gwarming = loadImage("gwarming.png");
  
  //Slide 3
  data1 = loadTable("melt.csv", "csv", "header");
  melting = loadImage("melting.png");
  
  sunI = loadImage('sun.png');
  cubeI = loadImage('cube.png');
  meltI = loadImage('melt.png');
  
  //Slide 4
  wtable = loadTable("waterlevels.csv", "csv", "header");
  NYBack = loadImage('NYBack.jpg');
  
  //Slide 5
  grasslands = loadImage("grasslands.jpg");
}

function setup() {
  createCanvas(750, 700);
  //populate array of slides with functions
  slides = [slide1, slide2, slide3, slide4,slide5];
  
  // The .getColumn gets the column of the dataset that is used for the slide.
  
  //Slide 2
  tempData = data.getColumn("TEMP");
  yearData = data.getColumn("YEAR");
  
  //Slide 3
  meltData = data1.getColumn("MELT");
  yearData1 = data1.getColumn("YEAR");
  
  // .getRowCount - returns the total number of rows in dataset.
  // .getColumnCount - returns the total number of columns in dataset.
  // both used in Line Graph created in slide 4.
  
  //Slide 4
  // w1 and h1 are used for the water rising animation used in slide 4.
  w1 = 750;
  h1 = 700;
  numberOfRows = wtable.getRowCount();
  numberOfColumns = wtable.getColumnCount();

}

function draw() {
  slides[currentSlide]();
}

//advance slide on mouse click
function mouseClicked(){
  clear();
  if(currentSlide < slides.length-1){
    currentSlide++; 
  }else{
    currentSlide = 0; //set back to zero if # slides exceded
  }
}

//put all your code for slide1 in this function - Title Slide
function slide1(){
    titleScreen();
    }


//put all your code for slide2 in this function - Global Warming Temperatures
function slide2(){
    tempGraph();
    textbox1();
    }


//put all your code for slide3 in this function - Polar Ice Caps melting
function slide3(){
    background(255);
    meltGraph();
    textbox2();
    }

//put all your code for slide4 in this function - Oceans Rising
function slide4(){
  image(NYBack, 0, 0, width, height);
  water(0,700,w1,h1);
  WaterLineGraph();
  // This helps create the rising water elevation using height. 
  h1  = h1 - 2;
  if(h1 == 700) {
    h1 = 0;
  }
  textbox3();
}

//put all your code for slide5 in this function - Solutions to Global Warming
function slide5(){
  image(grasslands, 0, 0, width, height);
  textbox4();
  lastsun();
  trees();
  stems();
  flower1(300,600,400);
  flower2(450,600,400);
} 

// Slide 1

function titleScreen(){
image(title, 0, 0, width, height); //background image
textFont('Georgia');
textStyle(BOLD);
textSize(30);
text('GLOBAL WARMING',25,50);
text('By: Nelson Corral',460,675);
}

//Slide 2

function tempGraph() {
textStyle(NORMAL);
image(gwarming, 0, 0, width, height); //background image 
sun();
for (i = 0; i < tempData.length; i++) { 
    var temp = tempData[i];
    var heightspacing = map(temp, 1, 2.5, 0, height); // determines the height of the bar graph.
    var widthspacing = i * 500 / 10 + 250; //determines how far apart each bar is away from each other.
    
    // Year Data
    fill("white");
    textSize(20);
    text(yearData[i], i * 500 / 10 + 235, height - 2);
  
    // Bar Graph and Temperature Display
    fill("red");
    rect(widthspacing, height - 25, 20, - heightspacing); // skinner
    fill("white");
    textSize(20);
    text("+" + tempData[i] + "°F", i * 500 / 10 + 225, height - heightspacing - 40);
}

}

function sun() {
  // creates multiple sun rays across the screen to personify the heat being produced here.
  fill(255, 255, 0, 5);
  for (j = 1; j < 20; j++){
    ellipse(0, 0, (frameCount % 400)*j, (frameCount % 400)*j);
  }
  // Sun Figure at Top Left
  fill(255, 255, 0);
  ellipse(5, 0, 400, 400);
}

function textbox1(){
  fill(252,94,94, 100);
  rect(350, 0, 400, 245);
  
  fill('white');
  text('Info:', 355, 20);
  text('• The Ten Hottest Years Have Come in the ', 355, 45);
  text('Past 15 Years!', 355, 70);
  text('• The Global Temperature has increased by', 355, 95);
  text('more than two degrees since the 19th', 355, 120);
  text('century.',355,145);
  text('•Leads to some very problematic concerns ', 355, 170);
  text('such as the melting of polar ice caps and ', 355, 195);
  text('rising sea levels.', 355, 220);
}

// Slide 3

function meltGraph() {
image(melting, 150, -30, width, height) // background image
for (i = 0; i < meltData.length; i++)   { 
    var melt = meltData[i];
    var heightspacing1 = map(melt, 2, 10, 0, height); // determines the height of the bar graph.
    var widthspacing1 = i * 500 / 25 + 310; //determines how far apart each bar is away from each other.
    
    // Year Data
    fill("black");
    textSize(14);
    text(yearData1[i], i * 500 / 25 + 312, height - 2);
  
    // Displays the Graph of Melting Arctic Ice Sheets
    fill(153,255,255);
    rect(widthspacing1, height - 25, 20, - heightspacing1); 
    fill("black");
    textSize(9);
    text(meltData[i] , i * 500 / 25 + 312, height - heightspacing1 - 40);
}
moveFunction();
}

// Uses two images and creates a melting animation using mouseX. 
// My animation inspiration: https://editor.p5js.org/ashoksuhani/sketches/Bk9FKpTrZ
function moveFunction() {
  
  var t1 = map(mouseX, 0, 400, 0, 255);
  var t2 = map(mouseX, 100, 600, 0, 255);
  
  tint(255, 255-t1);
  image(cubeI,100,500,100,100);
  
  tint(255, t2);
  image(meltI,100,600,100,100);
  
  noTint();
  image(sunI, mouseX, mouseY,150,150);
  
}

function textbox2(){
  fill(179,248,253, 100);
  rect(5, 170, 290, 320);
  
  textSize(15);
  fill('black');
  text('Info:', 10, 185);
  text('•helps keep polar regions cooler and helps', 10, 210);
  text('moderate the climate.', 10, 235);
  text('•Over the past decades, 9-13% of polars', 10, 285);
  text('ice caps have melted.', 10, 310);
  text('•150 Tons of Per Year are lost. ', 10, 360);
  text('•By a 2040 Projection, all of the polar ice', 10, 410);
  text('caps will be gone.', 10, 435);
}

// Slide 4

// This function is what is connected to for the water animation.
function water(x,y,w,h){
    fill(189, 246, 254, 150);
    rect(x,y,w,h);
}

// Line Graph Creation: https://editor.p5js.org/jsarachan/sketches/Hyul-6OC-

function WaterLineGraph() {
  fill(0);
  for (var i = 0; i < numberOfRows; i++) {
    // Years (Horizontal Axis)
    textSize(15);
    text(wtable.getString(i, 0), i * 80 + 50, 685);
    
    // Growth (Vertical Axis)
    waterValues[i] = wtable.getString(i, 1);
    
    //Line Graph
    line(i * 80 + 60, 655-waterValues[i], (i+1) * 80 + 60, 655-waterValues[i+1])
  }
   //Determines highest value
   maxValue=max(waterValues);
  for (var k=0;k<maxValue;k=k+50){
    text(k,10,655-k)
    //text('MM',40, 655-k);
  }

}

function textbox3(){
  fill(245,178,231, 100);
  rect(350, 0, 400, 245);
  
  textSize(20);
  fill('black');
  text('Info:', 355, 20)
  text('•If ALL Polar Ice Caps melted, we lose much', 355, 45);
  text('our curret coasts and many cities like NY', 355, 70);
  text('would be underwater.', 355, 95);
  text('•Ocean Levels have risen 7-8 inches in the', 355, 120);
  text('past century and still rise about 1/8 every yr.', 355, 145);
  text('•Could rise as high 20 ft by 2040.', 355, 170);
  text('•Climate Change and The Overall Effects.', 355, 195);
  
}


// Slide 5 

function textbox4(){
  fill(183,255,193, 100);
  rect(350, 0, 400, 210);
  fill('black');
  text('Info:', 355, 20);
  text('1. Reduce, Reuse, Recycle!', 355, 45);
  text('2. Plant a Tree or Donate Money.', 355, 70);
  text('3. Be More Efficient!', 355, 95);
  text('4. Change Light Bulbs.', 355, 120);
  text('5. Buy Local Food and Products.', 355, 145);
  
}

function lastsun() {
  // creates sun rays across the screen but less than the first slide to show less heat.
  stroke('black');
  fill(255, 255, 0, 5);
  for (z = 1; z < 5; z++){
    ellipse(0, 0, (frameCount % 400)*z, (frameCount % 400)*z);
  }
  // Creates the sun in the top left corner
  fill(255, 255, 0);
  ellipse(5, 0, 400, 400);
  noStroke();
}

function trees(){
  //Trunk of Left Tree
  fill("brown");
  rect(25, 500, 100, 300);
  
  //Leaves of Left Tree
  fill("green");
  ellipse(-5, 500, diam);
  ellipse(175, 500, diam);
  ellipse(75, 390, diam); //top
  ellipse(75, 490, diam);
  
  //Trunk of Right Tree
  fill("brown");
  rect(600, 500, 100, 300);

  //Leaves of Right Tree
  fill("green");
  ellipse(715, 500, diam);
  ellipse(575, 500, diam);
  ellipse(650, 390, diam);//top
  ellipse(625, 490, diam);
    
  // Creates the expansion of leaves to show growth.
    if(diam > 100){
	expand = false;
	}
	
	if(diam < 200){
	expand = true;
	}
	
	if(expand){
	diam++
	}
}

// Flower Stem Creation.

function stems() {
  
  //Left Stem
  stroke(124,252,0);
  strokeWeight(2);
  line(300, 600, 300, 700);
  noStroke();
  
  //Right Stem
  stroke(124,252,0);
  strokeWeight(2);
  line(450, 600, 450, 700);
  noStroke();
}

// Flower Creation

// Left Flower
function flower1(x1,y1,s) {
  translate(x1,y1); //Placement of Left Flower
  fill('red');
  // This function is used as a flower blooming to again emphasize growth. 
  for (var a = 0; a < 8; a++) {
    if (frameCount <= s) {      
      ellipse(0, frameCount / 15, frameCount / 20, frameCount / 10);
    }
    if (frameCount > s) {
      ellipse(0, 30, 25, 50);
    }
    rotate(PI/4);
  }
}



//Right Flower
function flower2(x2,y2,s) {
  translate(150,0); //From the placement of Left Flower, it moves x:150 to the right to place other flower. 
  fill('blue');
  //This function is used as a flower blooming to again emphasize growth. 
  for (var b = 0; b < 8; b++) {
    if (frameCount <= s) {      
      ellipse(0, frameCount / 15, frameCount / 20, frameCount / 10);
    }
    if (frameCount > s) {
      ellipse(0, 30, 25, 50);
    }
    rotate(PI/4);
  }
}








