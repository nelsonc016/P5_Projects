let w = 650;
let h = 600;

var key = 0;

var y = 280;
var speed = 1;
var gravity = 0.2;

function setup(){
	createCanvas(w, h);
}

// Calls in the "Title" Screen.
function draw(){
	basketball();
}   

// Function created in order to go to drawings.
function keyPressed(){
	// Goes to MJ drawing and it incorporates the GOAT image.
		if (key == '1') {
		background(255);
		background1();
		goat();
		traceimage1();
	// Goes to Kobe Drawing and it incorporates the GOAT image.
	} else if (key == '2') {
		background(255);
		background2();
		goat();
		traceimage2();
	}
	// Goes back to the "Title Screen".
	else if (key == 'b') {
		background(255);
		draw();
	}
	//Goes to Lebron Drawing and it incorporates the GOAT image.
	else if (key == '3') {
		background(255);
		background3();
		goat();
		traceimage3();
	}
} 



// "Title Screen" of Project
function basketball(){
	background(0);
	stroke("black");
	fill("orange");
	textSize(32);

	strokeWeight(4);
	ellipse(320,y,250,250); 
	
	//Bouncing Ball Effect
	y=y+speed;
  	speed=speed+gravity;
  
  	if(y>500){
  		//reverses the speed
    	speed=-0.98 * speed;
  } 
  	//Basketball Lines
	line(320,0,320,600); 
	line(195,y,445,y); // (195,y,445,y) y = 280
	line(219,y+70,422,y+70); //(219,350,422,350)
	line(219,y-70,422,y-70); // (219,210,422,210)

	stroke("white");
	textFont('Georgia');
	text('THE THREE GOATS',175,100);
	text('PRESS',265,490);
	text('1',175,550);
	text('2',310,550);
	text('3',445,545);

	textFont('Sans Serif');
	textSize(12);
	text('By: Nelson Corral', 550,580);
	noFill(); 
} 


// Drawing/Outline of the MJ Drawing.
function traceimage1(){
stroke("black");
strokeWeight(4);

//Jersey Outline
line(155,535,155,229);
bezier(155,229,155,229,220,220,200,85);
line(200,85,260,54);
bezier(260,54,260,54,325,100,385,54);
line(385,54,440,85);
bezier(440,85,440,85,420,210,488,229);
line(488,229,488,535);
bezier(488,535,488,535,310,570,155,535);

//Number 2
stroke("white");
strokeWeight(4);
line(312,422,234,422);
line(234,422,234,340);
line(234,340,248,322);
line(248,322,285,322);
line(286,322,286,294);
line(286,294,260,294);
line(260,294,260,313);
line(260,313,234,313);
line(234,313,234,277);
line(234,277,248,258);
line(248,258,299,258);
line(299,258,313,278);
line(313,278,313,340);
line(313,340,298,358);
line(298,358,260,358);
line(260,358,260,386);
line(260,386,286,386);
line(286,386,286,368);
line(286,368,312,368);
line(312,368,312,422);

//Number 3
line(393,422,345,422);
line(345,422,331,404);
line(331,404,331,367);
line(331,367,356,367);
line(356,367,356,386);
line(356,386,381,386);
line(381,386,381,358);
line(381,358,355,358);
line(355,358,355,322);
line(355,322,381,322);
line(381,322,381,294);
line(381,294,356,294);
line(356,294,356,313);
line(356,313,330,313);
line(330,313,330,277);
line(330,277,344,258);
line(344,258,393,258);
line(393,258,407,277);
line(407,277,407,330);
line(407,330,400,340);
line(400,340,407,350);
line(407,350,407,405);
line(407,405,393,422);
}

// Drawing/Outline of the Kobe Drawing.
function traceimage2(){
strokeWeight(4);
stroke("yellow");

//Jersey Outline
line(155,535,155,229);
bezier(155,229,155,229,220,220,200,85);
line(200,85,260,54);
bezier(260,54,260,54,325,100,385,54);
line(385,54,440,85);
bezier(440,85,440,85,420,210,488,229);
line(488,229,488,535);
bezier(488,535,488,535,310,570,155,535);

//Number 2
stroke("black");
line(312,422,234,422);
line(234,422,234,340);
line(234,340,248,322);
line(248,322,285,322);
line(286,322,286,294);
line(286,294,260,294);
line(260,294,260,313);
line(260,313,234,313);
line(234,313,234,277);
line(234,277,248,258);
line(248,258,299,258);
line(299,258,313,278);
line(313,278,313,340);
line(313,340,298,358);
line(298,358,260,358);
line(260,358,260,386);
line(260,386,286,386);
line(286,386,286,368);
line(286,368,312,368);
line(312,368,312,422);

//Number 4
line(410,422,355,422);
line(355,422,355,395); 
line(355,395,370,395);
line(370,395,370,368);
line(370,368,340,368);
line(340,368,325,350);
line(325,350,380,258);
line(380,258,395,258);
line(395,258,395,345);
line(410,422,410,395);
line(410,395,395,395);
line(395,395,395,368);
line(395,368,410,368);
line(410,368,410,345);
line(410,345,395,345);
line(370,345,350,345);
line(370,345,370,310);
line(370,310,350,345);


}

// Drawing/Outline of the Lebron Drawing.
function traceimage3(){
stroke(70,18,22);
strokeWeight(4);

//Jersey Outline
line(155,535,155,229);
bezier(155,229,155,229,220,220,200,85);
line(200,85,260,54);
bezier(260,54,260,54,325,100,385,54);
line(385,54,440,85);
bezier(440,85,440,85,420,210,488,229);
line(488,229,488,535);
bezier(488,535,488,535,310,570,155,535);

// Number 2
stroke("black");
strokeWeight(4);
line(312,422,234,422);
line(234,422,234,340);
line(234,340,248,322);
line(248,322,285,322);
line(286,322,286,294);
line(286,294,260,294);
line(260,294,260,313);
line(260,313,234,313);
line(234,313,234,277);
line(234,277,248,258);
line(248,258,299,258);
line(299,258,313,278);
line(313,278,313,340);
line(313,340,298,358);
line(298,358,260,358);
line(260,358,260,386);
line(260,386,286,386);
line(286,386,286,368);
line(286,368,312,368);
line(312,368,312,422);

// Number 3
line(393,422,345,422);
line(345,422,331,404);
line(331,404,331,367);
line(331,367,356,367);
line(356,367,356,386);
line(356,386,381,386);
line(381,386,381,358);
line(381,358,355,358);
line(355,358,355,322);
line(355,322,381,322);
line(381,322,381,294);
line(381,294,356,294);
line(356,294,356,313);
line(356,313,330,313);
line(330,313,330,277);
line(330,277,344,258);
line(344,258,393,258);
line(393,258,407,277);
line(407,277,407,330);
line(407,330,400,340);
line(400,340,407,350);
line(407,350,407,405);
line(407,405,393,422);
}

// The Background will matchup with the colorways of the jersey colors. 

// Creates a Red and Black Background
function background1(){
	background(255,0,0);
  	for(var i =0; i <650; i +=2){
    	strokeWeight(1);
    	stroke(0);
    	line(i,0,i,600);
    	line(0,i,650,i);
  }
  noLoop();
}

// Creates a Purple and Black Background
function background2(){
	background("purple");
	for(var i =0; i <650; i +=2){
    	strokeWeight(1);
    	stroke(0);
    	line(i,0,i,600);
    	line(0,i,650,i);
  }
  noLoop();
}

// Creates a Gold and Black Background
function background3(){
	background(218,165,32);
  	for(var i =0; i <650; i +=2){
    	strokeWeight(1);
    	stroke(0);
    	line(i,0,i,600);
    	line(0,i,650,i);
  }
  noLoop();
}

// Draws a Goat Image.
// Symbolizes "Greatest Of All Time" and respects the player.
function goat(){
stroke("black");
strokeWeight(4);

// Body of Goat
line(339,215,339,193);
line(339,193,350,164);
line(339,215,333,215);
line(333,215,333,193);
line(329,193,313,193); 
line(310,190,305,200);
line(305,200,308,215);
line(308,215,302,215);
line(302,215,300,200);
line(300,200,301,195);
line(301,195,300,186);
line(300,186,298,175);
line(298,175,300,168);
line(300,168,307,163);
line(307,163,337,163);
line(337,163,342,159);
line(342,159,346,151);
line(346,151,343,144);
line(343,144,349,146);
line(349,146,345,129);
line(345,129,348,124);
line(348,124,355,144);
line(355,144,354,148);
line(356,154,362,162);
line(362,162,362,166);
line(362,166,360,168);
line(360,168,355,162);
line(355,162,355,180);

//Tail of Goat
line(296,169,292,171);
line(292,171,292,183);
} 


